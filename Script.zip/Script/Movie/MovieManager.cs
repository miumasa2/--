using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Video;
using UnityEngine.SceneManagement;

public class MovieManager : MonoBehaviour
{
    // ビデオプレイヤー
    public VideoPlayer moviePlayer;
    
    // 再生する動画
    public VideoClip[] movies;
    
    public static string nextScene = "Titlemain";   // このシーンに移行する前に次のシーン名を指定しておく変数
    public static int movieID = -1;                 // このシーンに移行する前に再生する動画の要素番号を指定しておく変数
    // Start is called before the first frame update
    void Start()
    {
        // BGMを止める
        FindObjectOfType<SoundManager>().StopBgm();
        
        if(movieID >= 0 && movieID < movies.Length)
        {
            // 再生可能なら再生
            moviePlayer.clip = movies[movieID];
            moviePlayer.loopPointReached += MovieEnd;
            moviePlayer.Play();
        }
        else
        {
            // 再生できないならタイトルに戻る
            SceneManager.LoadScene("Titlemain");
        }
    }
    
    // 再生終了時の処理
    public void MovieEnd(VideoPlayer vp)
    {
        SceneManager.LoadScene(nextScene);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
