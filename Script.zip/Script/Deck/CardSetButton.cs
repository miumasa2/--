using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CardSetButton : MonoBehaviour
{

    
    public CardDeck cardDeck;
    public CardManager cardManager;
    
    public int CardId = -1;
    public int CardSetNum;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    //�J�[�h�N���b�N�����ۂ��̃J�[�h���Ăяo��
    public void CardSetButtonClick()
    {
       if(CardId == -1)
        {
            return;
        }
        
       if(cardManager.cards[CardId].holdNumber == 0)
        {
         return;
        }
        
         cardDeck.CardSet(CardId);
         cardDeck.CardDeckDisplay();
    }

}
