using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public  class DeckCase : MonoBehaviour
{
    public static int SelectDeckCase;
    public int DeckID;


    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void Click()
    {
        SelectDeckCase = DeckID;
    }
}
