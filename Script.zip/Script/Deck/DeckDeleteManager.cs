using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class DeckDeleteManager : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    
    public void DeleteDeck()
    {
        int[] deck = SaveManager.DeckLoad(DeckCase.SelectDeckCase);
        for(int i=0; i<deck.Length; i++)
        {
            int num = SaveManager.CardNumLoad(deck[i]) + 1;
            SaveManager.CardNumSave(deck[i], num);
            deck[i] = -1;
        }
        SaveManager.DeckSave(DeckCase.SelectDeckCase, deck);
        SceneManager.LoadScene("Deck");
    }
}
