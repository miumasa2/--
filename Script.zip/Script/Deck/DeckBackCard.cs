using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DeckBackCard : MonoBehaviour
{
  public CardDeck carddeck;
  public CardManager cardManager;
  public int DeckNum;

  
      // Start is called before the first frame update
    void Start()
    {
            carddeck = GameObject.Find("CardDeck").GetComponent<CardDeck>();
            cardManager = GameObject.Find("CardManager").GetComponent<CardManager>();

    }

    // Update is called once per frame
    void Update()
    {
        
    }
    
    public void DeckBackCardSet()
    {
    
      if(carddeck.cardDeck[DeckNum] == -1)
      {
       return;
      }
      
      cardManager.cards[carddeck.cardDeck[DeckNum]].holdNumber += 1; 
    
      carddeck.cardDeck[DeckNum] = -1;
      carddeck.CardDeckDisplay();
      Debug.Log("Deck");
    }
}
