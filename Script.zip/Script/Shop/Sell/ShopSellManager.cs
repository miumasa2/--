using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ShopSellManager : MonoBehaviour
{
    public SellCardsManager sellCards;
    
    // Start is called before the first frame update
    void Start()
    {
        sellCards.ResetNum();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    
    public void ClickSellButton()
    {
        SceneManager.LoadScene("sellcard");
    }
    
    public void BackToShop()
    {
        SceneManager.LoadScene("shop");
    }
}
