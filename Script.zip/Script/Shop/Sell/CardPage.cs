using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;

public class CardPage : MonoBehaviour
{
    public SellCard[] cards;
    public Text pageText;
    
    private int[] sellCardsID = Array.Empty<int>();
    private int maxPage;
    private int pageNum = 0;
    
    // Start is called before the first frame update
    void Start()
    {
        int m = CardData.GetAllCardDataNum();
        for(int i=0; i<m; i++)
        {
            if(SaveManager.CardNumLoad(i) > 0)
            {
                int n = sellCardsID.Length;
                Array.Resize(ref sellCardsID, n+1);
                sellCardsID[n] = i;
            }
        }
        if(sellCardsID.Length > 0)
        {
            maxPage = (int) Mathf.Ceil((float)sellCardsID.Length/cards.Length);
        }
        else
        {
            maxPage = 1;
        }
        ShowPage();
    }
    
    // 次のページ
    public void NextPage()
    {
        if(++pageNum >= maxPage)
        {
            pageNum = 0;
        }
        ShowPage();
    }
    
    // 前のページ
    public void BackPage()
    {
        if(--pageNum < 0)
        {
            pageNum = maxPage - 1;
        }
        ShowPage();
    }
    
    // 売却可能なカードの一覧をページ単位で表示
    private void ShowPage()
    {
        int index = pageNum * cards.Length;
        for(int i=0; i<cards.Length; i++)
        {
            if(index + i < sellCardsID.Length)
            {
                cards[i].gameObject.SetActive(true);
                cards[i].Init(sellCardsID[index + i]);
            }
            else
            {
                cards[i].gameObject.SetActive(false);
            }
        }
        pageText.text = (pageNum + 1) + "/" + maxPage;
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.D))
        {
            NextPage();
        }
        
        if(Input.GetKeyDown(KeyCode.A))
        {
            BackPage();
        }
    }
}
