using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SellCard : MonoBehaviour
{
    public Image back, cardImage, frame, janken;
    public Text cardName, attack, defense, cardNumText;
    
    public SellCardsManager sellCardsManager;
    
    private int cardID;
    private int cardNum;
    
    // カードを設定
    public void Init(int id)
    {
        CardData data = new CardData(id);
        
        back.sprite = Resources.Load("Back/back" + data.back, typeof(Sprite)) as Sprite;
        cardImage.sprite = data.cardImage;
        frame.sprite = Resources.Load("CardFrame/FrameRank" + data.rarity, typeof(Sprite)) as Sprite;
        janken.sprite = Resources.Load("JankenImage/" + data.type, typeof(Sprite)) as Sprite;
        
        cardName.text = data.name;
        attack.text = "" + data.pow;
        defense.text = "" + data.def;
        
        cardID = data.id;
        cardNum = SaveManager.CardNumLoad(cardID);
    }
    
    // Start is called before the first frame update
    void Start()
    {
        
    }
    
    // クリック時に呼ばれる
    public void SelectSellCard()
    {
        sellCardsManager.SetSellCard(cardID);
    }

    // Update is called once per frame
    void Update()
    {
        // 選択分を除くカード枚数を表示する
        cardNumText.text = "" + (cardNum - SellCardsManager.sellCardsNum[cardID]);
    }
}
