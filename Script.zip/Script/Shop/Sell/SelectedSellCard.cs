using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SelectedSellCard : MonoBehaviour
{
    public Image back, cardImage, frame, janken;
    public Text cardName, attack, defense, cardNum;
    
    private int cardID; // カードのID
    
    // カードを設定
    public void Init(int id)
    {
        CardData data = new CardData(id);
        
        back.sprite = Resources.Load("Back/back" + data.back, typeof(Sprite)) as Sprite;
        cardImage.sprite = data.cardImage;
        frame.sprite = Resources.Load("CardFrame/FrameRank" + data.rarity, typeof(Sprite)) as Sprite;
        janken.sprite = Resources.Load("JankenImage/" + data.type, typeof(Sprite)) as Sprite;
        
        cardName.text = data.name;
        attack.text = "" + data.pow;
        defense.text = "" + data.def;
        
        cardID = data.id;
    }
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        // 売却枚数を表示
        cardNum.text = "×" + SellCardsManager.sellCardsNum[cardID];
    }
}
