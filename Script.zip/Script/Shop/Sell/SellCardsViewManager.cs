using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class SellCardsViewManager : MonoBehaviour
{
    public SellCardsManager manager;
    public GameObject selectedSellCardPrefab;
    public Transform cardsViewContent;
    
    // Start is called before the first frame update
    void Start()
    {
        GameObject obj;
        for(int i=0; i<SellCardsManager.selectNum.Length; i++)
        {
            int id = SellCardsManager.selectNum[i];
            obj = Instantiate(selectedSellCardPrefab, cardsViewContent);
            obj.GetComponent<SelectedSellCard>().Init(id);
        }
    }
    
    public void CanselSell()
    {
        SceneManager.LoadScene("sell");
    }
    
    public void SellCards()
    {
        for(int i=0; i<SellCardsManager.selectNum.Length; i++)
        {
            int id = SellCardsManager.selectNum[i];
            int num = SaveManager.CardNumLoad(id) - SellCardsManager.sellCardsNum[id];
            SaveManager.CardNumSave(id, num);
        }
        int money = SaveManager.MoneyLoad() + manager.price;
        SaveManager.MoneySave(money);
        
        manager.ResetNum();
        
        SceneManager.LoadScene("sell");
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
