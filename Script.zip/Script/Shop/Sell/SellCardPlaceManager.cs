using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class SellCardPlaceManager : MonoBehaviour
{
    public GameObject selectedSellCardPrefab;
    public Transform sellCardPlace;
    
    private GameObject[] sellCards;
    
    // Start is called before the first frame update
    void Start()
    {
        sellCards = new GameObject[CardData.GetAllCardDataNum()];
    }
    
    public void SetSellCards()
    {
        for(int i=0; i<sellCards.Length; i++)
        {
            if(i < SellCardsManager.selectNum.Length)
            {
                if(sellCards[i] == null)
                {
                    sellCards[i] = Instantiate(selectedSellCardPrefab, sellCardPlace);
                    sellCards[i].SetActive(false);
                }
                
                sellCards[i].GetComponent<SelectedSellCard>().Init(SellCardsManager.selectNum[i]);
                sellCards[i].SetActive(true);
                sellCards[i].transform.localPosition = Vector3.left * (i%5) * 4.0f + Vector3.up * (i%5) * 6.0f + Vector3.left * (i/5) * 6.0f;
            }
            else if(sellCards[i] != null)
            {
                Destroy(sellCards[i]);
            }
            else
            {
                break;
            }
        }
    }
    
    public void DestroyCards()
    {
        for(int i=0; i<sellCards.Length; i++)
        {
            if(sellCards[i] != null)
            {
                Destroy(sellCards[i]);
            }
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
