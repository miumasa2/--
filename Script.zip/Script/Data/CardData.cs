using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

// カードデータ管理用クラス
public class CardData
{
    public int id;  // カードID
    public int pow; // 攻撃力
    public int def; // 防御力
    public int type;    // じゃんけんの手（0:グー,1:チョキ,2:パー）
    public string name; // カード名
    public Sprite cardImage;    // カードの絵
    public int rarity;    // カードのランク。フレームの色の決定に使用
    public int back;    // カードの背景

    // 指定したIDのカード情報を取得
    public CardData(int id)
    {
        CardEntity entity = Resources.Load<CardEntity>("CardEntityList/CardEntity" + id);
        if(entity == null)return;
        
        this.id = entity.ID;
        this.pow = entity.cardAttack;
        this.def = entity.cardDefense;
        this.type = entity.janken;
        this.name = entity.cardName;
        this.cardImage = entity.cardSprite;
        this.rarity = entity.rarity;
        this.back = entity.backID;
    }
    
    // カードの種類数を返す
    public static int GetAllCardDataNum()
    {
        Object[] obj = Resources.LoadAll("CardEntityList");
        int res = obj.Length;
        //現在使用していないアセットを破棄する
        Resources.UnloadUnusedAssets();
        return res;
    }
}
