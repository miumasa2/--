using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;

public class ItemData
{
    public int id;      // ID
    public string name; // 名前
    public int capa;    // 性能
    public int price;   // 値段
    public int effect;  // 効果の種類
    public Sprite image;    // アイテムイメージ
    
    // 全アイテムデータを格納
    private static ItemData[] itemdatabase = Array.Empty<ItemData>();
    
    private ItemData(string[] data)
    {
        this.id = int.Parse(data[0]);
        this.name = data[1];
        this.capa = int.Parse(data[2]);
        this.price = int.Parse(data[3]);
        this.effect = int.Parse(data[4]);
        
        this.image = Resources.Load("ItemImage/item" + (this.id+1).ToString("000"), typeof(Sprite)) as Sprite;
    }
    
    // 全アイテム情報を設定
    public static void Load()
    {
        string[,] data;
        CSVManager.LoadData("アイテム", out data);
        if(itemdatabase.Length < data.GetLength(0))
        {
            Array.Resize(ref itemdatabase, data.GetLength(0));
        }
        for(int i=0; i<data.GetLength(0); i++)
        {
            string[] str = new string[data.GetLength(1)];
            for(int j=0; j<data.GetLength(1); j++)
            {
                str[j] = data[i,j];
            }
            itemdatabase[i] = new ItemData(str);
        }
    }
    
    // 指定したIDのアイテム情報を返す
    public static ItemData GetItemData(int id)
    {
        if(itemdatabase.Length == 0)
        {
            Load();
        }
        for(int i=0; i<itemdatabase.Length; i++)
        {
            if(itemdatabase[i].id == id)
            {
                return itemdatabase[i];
            }
        }
        return null;
    }
    
    // 全アイテムの種類数を返す
    public static int GetItemDataNum()
    {
        if(itemdatabase.Length == 0)
        {
            Load();
        }
        return itemdatabase.Length;
    }
}
