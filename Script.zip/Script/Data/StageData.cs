using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

// ステージ情報管理用クラス
public class StageData
{
    public int id;  // ID
    public int islandID;    // 島ID
    public int stageID;     // 島ごとのステージID
    public string name;     // ステージ名
    public EnemyData[] enemies = Array.Empty<EnemyData>();  // 敵の情報の配列
    public int[] field = Array.Empty<int>();    // フィールドの属性情報の配列
    public int gold;    // 報酬（お金）
    public int[] dropcardID = Array.Empty<int>();   // 報酬（カード）
    
    // 全ステージデータを格納
    private static StageData[] stagedatabase = Array.Empty<StageData>();
    
    private StageData(string[] data)
    {
        this.id = int.Parse(data[0]);
        this.stageID = int.Parse(data[1])-1;
        this.islandID = int.Parse(data[2])-1;
        this.name = data[3];
        
        for(int i=0; i<5; i++)
        {
            if(data[4+i].Equals(""))
            {
                break;
            }
            Array.Resize(ref enemies, i+1);
            this.enemies[i] = EnemyData.GetEnemyData(int.Parse(data[4+i]));
        }
        
        for(int i=0; i<5; i++)
        {
            if(data[9+i].Equals(""))
            {
                break;
            }
            Array.Resize(ref field, i+1);
            this.field[i] = int.Parse(data[9+i]);
            if(field[i] == 0) field[i] = 2;
            else if(field[i] == 1) field[i] = 3;
            else if(field[i] == 2) field[i] = 1;
            else if(field[i] == 3) field[i] = 0;
        }
        
        if(data[14].Equals(""))
        {
            this.gold = 0;
        }
        else
        {
            this.gold = int.Parse(data[14]);
        }
        
        for(int i=0; i<5; i++)
        {
            if(data[15+i].Equals(""))
            {
                break;
            }
            Array.Resize(ref dropcardID, i+1);
            dropcardID[i] = int.Parse(data[15+i])-1;
        }
    }
    
    // 全ステージデータを設定
    public static void Load()
    {
        string[,] data;
        CSVManager.LoadData("マップ", out data);
        if(stagedatabase.Length < data.GetLength(0))
        {
            Array.Resize(ref stagedatabase, data.GetLength(0));
        }
        for(int i=0; i<data.GetLength(0); i++)
        {
            string[] str = new string[data.GetLength(1)];
            for(int j=0; j<data.GetLength(1); j++)
            {
                str[j] = data[i,j];
            }
            stagedatabase[i] = new StageData(str);
        }
    }
    
    // 指定したIDのステージ情報を返す
    public static StageData GetStageData(int id)
    {
        if(stagedatabase.Length == 0)
        {
            Load();
        }
        
        for(int i=0; i<stagedatabase.Length; i++)
        {
            if(stagedatabase[i].id == id)
            {
                return stagedatabase[i];
            }
        }
        return null;
    }
    
    // 島IDと島ごとのステージIDからステージ情報を返す
    public static StageData GetStageData(int islandId, int stageId)
    {
        if(stagedatabase.Length == 0)
        {
            Load();
        }
        
        for(int i=0; i<stagedatabase.Length; i++)
        {
            if(stagedatabase[i].islandID == islandId && stagedatabase[i].stageID == stageId)
            {
                return stagedatabase[i];
            }
        }
        return null;
    }
    
    // 指定した島IDのステージ情報を配列で返す（第二引数にステージ情報を格納する配列を指定する）
    public static void GetMapData(int islandId, out StageData[] stages)
    {
        StageData[] s = Array.Empty<StageData>();
        int n = 0;
        if(stagedatabase.Length == 0)
        {
            Load();
        }
        for(int i=0; i<stagedatabase.Length; i++)
        {
            if(stagedatabase[i].islandID == islandId)
            {
                Array.Resize(ref s, n+1);
                s[n] = stagedatabase[i];
                n++;
            }
        }
        stages = s;
    }
    
    // ステージ数を返す
    public static int GetStageNumAll()
    {
        if(stagedatabase.Length == 0)
        {
            Load();
        }
        return stagedatabase.Length;
    }
}
