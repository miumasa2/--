using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class EnemyData
{
    public int id;                              // ID
    public string name;                         // 名称
    public int hp;                              // HP
    public int power;                           // 攻撃力
    public Sprite image;                        // イラスト
    public int[] patterns = Array.Empty<int>(); // 手のパターン集
    
    // 全敵情報を格納する
    private static EnemyData[] enemydatabase = Array.Empty<EnemyData>();
    
    private EnemyData(string[] data)
    {
        this.id = int.Parse(data[0]);
        this.name = data[1];
        this.hp = int.Parse(data[2]);
        this.power = int.Parse(data[3]);
        this.image = Resources.Load("EnemyImage/"+data[4], typeof(Sprite)) as Sprite;
        
        int n = 0;
        for(int i=0; i<5; i++)
        {
            if(data[5+i].Equals("1"))
            {
                Array.Resize(ref patterns, n+1);
                patterns[n] = i;
                n++;
            }
        }
    }
    
    // 全敵情報を設定
    public static void Load()
    {
        string[,] data;
        CSVManager.LoadData("敵", out data);
        
        int n =0;
        
        for(int i=0; i<data.GetLength(0); i++)
        {
            string[] str = new string[data.GetLength(1)];
            if(data[i,0].Equals(""))continue;
            for(int j=0; j<data.GetLength(1); j++)
            {
                str[j] = data[i,j];
            }
            Array.Resize(ref enemydatabase, n+1);
            enemydatabase[n] = new EnemyData(str);
            n++;
        }
    }
    
    // IDから敵情報を返す
    public static EnemyData GetEnemyData(int id)
    {
        for(int i=0; i<enemydatabase.Length; i++)
        {
            if(enemydatabase[i].id == id)
            {
                return enemydatabase[i];
            }
        }
        
        Load();
        
        for(int i=0; i<enemydatabase.Length; i++)
        {
            if(enemydatabase[i].id == id)
            {
                return enemydatabase[i];
            }
        }
        
        return null;
    }
}
