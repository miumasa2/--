using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;

// CSVファイルを読み込むためのクラス
public class CSVManager
{
    // 第１引数にファイル名、第２引数に読み込んだ内容を入れる文字列型の２次元配列、戻り値は読み込んだ行数
    public static int LoadData(string csvname, out string[,] data)
    {
        TextAsset csv = Resources.Load("Data/"+csvname) as TextAsset;
        StringReader reader = new StringReader(csv.text);
        List<string[]> csvData = new List<string[]>();
        
        reader.ReadLine();
        
        while(reader.Peek() != -1)
        {
            string line = reader.ReadLine();
            csvData.Add(line.Split(','));
        }
        
        data = new string[csvData.Count,csvData[0].Length];
        
        for(int i=0; i<csvData.Count; i++)
        {
            for(int j=0; j<csvData[i].Length; j++)
            {
                string w = csvData[i][j];
                data[i,j] = w;
            }
        }
        
        int n = csvData.Count;
        return n;
    }
}
