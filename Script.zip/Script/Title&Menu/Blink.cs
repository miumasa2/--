using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Blink : MonoBehaviour {

    //public
    public float speed = 1.0f;

    //private
    private Text text;
    private Image image;
    private float time;

    private enum ObjType{
        TEXT,
        IMAGE
    };
    private ObjType thisObjType = ObjType.TEXT;

    void Start() {
        //�A�^�b�`���Ă�I�u�W�F�N�g�𔻕�
        if (this.gameObject.GetComponent<Image>()) {
            thisObjType = ObjType.IMAGE;
            image = this.gameObject.GetComponent<Image>();
        }else if (this.gameObject.GetComponent<Text>()) {
            thisObjType = ObjType.TEXT;
            text = this.gameObject.GetComponent<Text>();
        }  
    }
    
    public void yobidasi(){
    StartCoroutine ("aa");
    }
     
   
    private IEnumerator  aa () {
        bool flag = false;
        FindObjectOfType<SoundManager>().PlaySeByName("������ ���ʉ� �V�X�e��49");
        for(int i=0 ;i<=15;i++){
        //�I�u�W�F�N�g��Alpha�l���X�V
        if (thisObjType == ObjType.IMAGE) {
            image.color = GetAlphaColor(image.color, flag);
        }
        else if (thisObjType == ObjType.TEXT) {
            text.color = GetAlphaColor(text.color, flag);
        }
        flag = !flag;
        yield return new WaitForSeconds(0.3f);
        }
        yield break;
    }

    //Alpha�l���X�V����Color��Ԃ�
    private Color GetAlphaColor(Color color, bool flag) {
        time += Time.deltaTime * 1.0f * speed;
        color.a = Mathf.Sin(time) * 0.1f + 0.1f;
        if(flag)
        {
            color.a = 1.0f;
        }
        else
        {
            color.a = 0.0f;
        }

        return color;
    }
}