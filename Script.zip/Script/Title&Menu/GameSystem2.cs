using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class GameSystem2 : MonoBehaviour
{

	// シーン切り替え時にBGMチェンジ
	void Start()
	{
	    
	}
	
	//　スタートボタンを押したら実行する
	public void StartGame()
	{
	StartCoroutine("startPush");
	}
	
	IEnumerator startPush()
    {
        
        yield return new WaitForSeconds(1.5f);
        SceneManager.LoadScene("Game");

    }
}
