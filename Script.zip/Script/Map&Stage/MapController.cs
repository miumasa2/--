using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MapController : MonoBehaviour
{
    public static int selectIslandID;  // 選択された島のID
    public GameObject[] isLand;        // 島
    // Start is called before the first frame update
    void Start()
    {
        bool[] cStage = SaveManager.ClearStageLoad();
        bool[] oStage = SaveManager.OpenStageLoad();
        for(int i=0; i<isLand.Length; i++)
        {
            StageData data = StageData.GetStageData(i, 0);
            if(oStage[data.id] == false)
            {
                isLand[i].SetActive(false);
                if(data.id == 0)
                {
                    oStage[data.id] = true;
                }
                else if(cStage[data.id-1] == true)
                {
                    oStage[data.id] = true;
                }
            }
            if(oStage[data.id])
            {
                isLand[i].SetActive(true);
            }
        }
        SaveManager.OpenStageSave(oStage);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
