using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Island : MonoBehaviour
{
    public int id;
    private bool flag = true;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    
    public void SelectedIsland()
    {
        if(flag)
        {
            MapController.selectIslandID = id;
            SceneManager.LoadScene("Stage");
        }
    }
}
