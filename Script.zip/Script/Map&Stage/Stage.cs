using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Stage : MonoBehaviour
{
    public int id;
    public Text StageName;
    public Image StageImage;
    public StageController stageController;
    
    // フィールド名
    private string[] s = {"mori", "sougen", "umi", "sabaku", "sora"};
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    
    // ステージをセット
    public void SetStage(StageData data)
    {
        this.id = data.id;
        this.StageName.text = data.name;
        this.StageImage.sprite = Resources.Load("Map&Stage/"+s[data.field[0]]+1, typeof(Sprite)) as Sprite;
        
        Vector3 pos = this.gameObject.transform.localPosition;
        switch(this.id)     // 各ステージの座標を指定
        {
        case 0: // 1-1
            pos = new Vector3(-10, 100, 0);
            break;
        case 1: // 1-2
            pos = new Vector3(10, 0, 0);
            break;
        case 2: // 1-3
            pos = new Vector3(140, -40, 0);
            break;
        case 3: // 1-4
            pos = new Vector3(-160, -120, 0);
            break;
        case 4: // 1-5
            pos = new Vector3(-35, -140, 0);
            break;
        
        case 5: // 2-1
            pos = new Vector3(-45, 70, 0);
            break;
        case 6: // 2-2
            pos = new Vector3(80, 20, 0);
            break;
        case 7: // 2-3
            pos = new Vector3(-20, -20, 0);
            break;
        case 8: // 2-4
            pos = new Vector3(120, -50, 0);
            break;
        case 9: // 2-5
            pos = new Vector3(160, -120, 0);
            break;
        
        case 10:// 3-1
            pos = new Vector3(-180, 80, 0);
            break;
        case 11:// 3-2
            pos = new Vector3(-160, 10, 0);
            break;
        case 12:// 3-3
            pos = new Vector3(-70, -20, 0);
            break;
        case 13:// 3-4
            pos = new Vector3(0, -70, 0);
            break;
        case 14:// 3-5
            pos = new Vector3(100, -5, 0);
            break;
        
        case 15:// 4-1
            pos = new Vector3(-40, 130, 0);
            break;
        case 16:// 4-2
            pos = new Vector3(-30, 60, 0);
            break;
        case 17:// 4-3
            pos = new Vector3(50, -15, 0);
            break;
        case 18:// 4-4
            pos = new Vector3(0, -80, 0);
            break;
        case 19:// 4-5
            pos = new Vector3(130, -120, 0);
            break;
        
        case 20:// 5-1
            pos = new Vector3(70, 150, 0);
            break;
        case 21:// 5-2
            pos = new Vector3(-70, 30, 0);
            break;
        case 22:// 5-3
            pos = new Vector3(35, 0, 0);
            break;
        case 23:// 5-4
            pos = new Vector3(-50, -80, 0);
            break;
        case 24:// 5-5
            pos = new Vector3(70, -110, 0);
            break;
        }
        this.gameObject.transform.localPosition = pos;
    }
    
    // ステージ選択時に呼ばれる
    public void SelectStage()
    {
        StageController.selectStageID = id;
        stageController.NextScene();
    }
}
