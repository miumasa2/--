using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class StageController : MonoBehaviour
{
    public static int selectStageID;    // 選択されたステージID
    
    public Image islandImage;
    public Image islandName;
    public GameObject stage;
    public Transform stagesField;
    private int id;
    private bool movieFlag = false;
    // Start is called before the first frame update
    void Start()
    {
        SetIsland();
    }
    
    void SetIsland()
    {
        id = MapController.selectIslandID;
        islandImage.sprite = Resources.Load("Map&Stage/sima"+(id+1).ToString("000"), typeof(Sprite)) as Sprite;
        islandName.sprite = Resources.Load("Map&Stage/sima"+(id+1).ToString("000")+",name,Tx", typeof(Sprite)) as Sprite;
        
        Vector3 pos = islandImage.gameObject.transform.localPosition;
        Vector3 scale = islandImage.gameObject.transform.localScale;
        switch(id)  // 各島の座標等を調整
        {
            case 0: // 島１
                pos = new Vector3(0, 10, 0);
                break;
            case 1: // 島２
                pos = new Vector3(0, 0, 0);
                scale = new Vector3(4.2f, 4.2f, 0);
                break;
            case 2: // 島３
                pos = new Vector3(0, -32, 0);
                break;
            case 3: // 島４
                pos = new Vector3(48, -48, 0);
                break;
            case 4: // 島５
                pos = new Vector3(0, -32, 0);
                break;
        }
        islandImage.gameObject.transform.localPosition = pos;
        islandImage.gameObject.transform.localScale = scale;
        
        movieFlag = false;
        SetStages();
    }
    
    void SetStages()    // ステージを設置する
    {
        StageData[] stagesData;
        StageData.GetMapData(id, out stagesData);
        stage.GetComponent<Stage>().SetStage(stagesData[0]);
        for(int i=1; i<stagesData.Length; i++)
        {
            if(SaveManager.OpenStageLoad(stagesData[i].id))
            {
                Instantiate(stage, stagesField).GetComponent<Stage>().SetStage(stagesData[i]);
            }
            else if(SaveManager.ClearStageLoad(stagesData[i].id-1))
            {
                if(id == 0 && stagesData[i].field[0] == 2)
                {
                    movieFlag = true;
                }
                Instantiate(stage, stagesField).GetComponent<Stage>().SetStage(stagesData[i]);
            }
        }
    }
    
    public void NextScene() // 次のシーンに移行する。条件によって遷移先を変更
    {
        int[] deck = SaveManager.DeckLoad();
        for(int i=0; i<deck.Length; i++)
        {
            if(deck[i] == -1)
            {
                return;
            }
        }
        SaveManager.OpenStageSave(selectStageID, true);
        if(movieFlag)
        {
            StageData data = StageData.GetStageData(selectStageID);
            if(data.field[0] == 2)
            {
                MovieManager.nextScene = "Battle";
                MovieManager.movieID = 1;
                SceneManager.LoadScene("Movie");
            }
        }
        else
        {
            SceneManager.LoadScene("Battle");
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
