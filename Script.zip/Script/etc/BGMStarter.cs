using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BGMStarter : MonoBehaviour
{
    public string[] startBGMName; // インスペクタで曲名を指定
    // Start is called before the first frame update
    void Start()
    {
        // 指定した曲をBGMで再生
        if(startBGMName.Length > 0)
        {
            FindObjectOfType<SoundManager>().PlayBgmByName(startBGMName[Random.Range(0, startBGMName.Length)]);
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
