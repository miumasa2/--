using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Enemy : MonoBehaviour
{
    private int maxHp;          // 最大HP
    private int hp;             // 現在HP
    private int pow;            // 攻撃力
    private int janken;         // じゃんけんの手
    private int pattern;        // 手のパターン
    private string enemyName;   // 敵の名称
    
    public EnemyImage enemyImage;
    public EnemyJankenImage enemyJankenImage;
    public HP enemyHP;
    public Text enemyNameText;
    
    // 敵を設定する
    public void Init(EnemyData data)
    {
        maxHp = data.hp;
        hp = maxHp;
        pow = data.power;
        janken = Random.Range(0, 3);
        pattern = data.patterns[Random.Range(0, data.patterns.Length)];
        enemyName = data.name;
        
        enemyImage.SetImage(data.image);
        enemyHP.ShowHP(maxHp, hp);
        enemyNameText.text = enemyName;
    }
    
    // 動作可能状態かどうか
    public bool IsOK()
    {
        return enemyImage.IsOK();
    }
    
    // 敵の次の手を取得する
    public int GetJanken()
    {
        switch(pattern)
        {
            case 0:
                // 前より弱い手を出す
                janken++;
                break;
            case 1:
                // 前より強い手を出す
                janken--;
                break;
            case 2:
                // 前と同じか弱い手を出す
                janken += Random.Range(0, 2);
                break;
            case 3:
                // 前と同じか強い手を出す
                janken -= Random.Range(0, 2);
                break;
            case 4:
                // 前回とは違う手を出す
                if(Random.Range(0, 2) == 0)
                {
                    janken++;
                }
                else
                {
                    janken--;
                }
                break;
            default:
                // その他（ランダムな手を出す）
                janken = Random.Range(0, 3);
                // 次回以降パターンを0とする
                pattern = 0;
                break;
        }
        
        // jankenの値を0~2に調整する
        janken = (janken + 3) % 3;
        
        enemyJankenImage.SetJanken(janken);
        
        return janken;
    }
    
    // 敵の攻撃力を取得
    public int GetPow()
    {
        return pow;
    }
    
    // 敵のHPを取得
    public int GetHP()
    {
        return hp;
    }
    
    // 敵のイラストを取得
    public Sprite GetImage()
    {
        return enemyImage.image.sprite;
    }
    
    // ダメージ処理
    public void Damage(int damage)
    {
        hp -= damage;
        
        // hpが0を下回らないようにする
        if(hp < 0)
        {
            hp = 0;
        }
        
        enemyHP.ShowHP(maxHp, hp);
        
        if(hp == 0)
        {
            enemyImage.SetFadeOut();
        }
    }
    
    // 敵の手を取得
    public int GetJankenNow()
    {
        return janken;
    }
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
