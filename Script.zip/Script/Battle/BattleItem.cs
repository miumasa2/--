using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BattleItem : MonoBehaviour
{
    public Image itemImage;
    public GameObject frame;
    public Text itemNumText;
    
    private ItemData itemData;  // アイテムデータ
    private int num;            // アイテムの個数
    private bool useFlag;       // アイテムの使用可能状態を示すフラグ
    
    public void SetItem(int id) // アイテムを設定
    {
        if(id == -1 || id >= ItemData.GetItemDataNum())
        {
            useFlag = false;
            num = 0;
            return;
        }
        itemData = ItemData.GetItemData(id);
        itemImage.sprite = itemData.image;
        num = SaveManager.ItemLoad(itemData.id);
        if(num == 0)
        {
            useFlag = false;
        }
        else
        {
            useFlag = true;
        }
    }
    
    public void ClickItem() // クリックされた時の処理
    {
        if(useFlag)
        {
            BattleManager.instance.SupportItem(itemData);
            useFlag = false;
            num--;
            SaveManager.ItemSave(itemData.id, num);
        }
    }
    
    public void ResetUseFlag()  // 使用可能状態をリセットする処理。毎ターン開始時にBattleManagerから呼ばれる
    {
        if(num == 0)
        {
            useFlag = false;
        }
        else
        {
            useFlag = true;
        }
    }
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        frame.SetActive(!useFlag);
        itemNumText.text = "" + num;    // アイテムの個数を表示する
    }
}
