using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CardController : MonoBehaviour
{
    [SerializeField] private Text cardname, attack, def;
    [SerializeField] private Image type;
    [SerializeField] private Image image;
    [SerializeField] private Image back;
    [SerializeField] private Image frame;
    
    private int handId; // 手札の要素番号
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    // カードをセット（手札の要素番号を含む）
    public void SetCard(CardData data, int n)
    {
        SetCard(data);
        
        handId = n;
    }
    
    // カードをセット
    public void SetCard(CardData data)
    {
        this.cardname.text = data.name;
        this.attack.text = "" + data.pow;
        this.def.text = "" + data.def;
        this.image.sprite = data.cardImage;
        this.type.sprite = Resources.Load("JankenImage/" + data.type, typeof(Sprite)) as Sprite;
        this.frame.sprite = Resources.Load("CardFrame/FrameRank" + data.rarity, typeof(Sprite)) as Sprite;
        this.back.sprite = Resources.Load("Back/back" + data.back, typeof(Sprite)) as Sprite;
    }
    
    // クリックされた時の処理
    public void ClickCard()
    {
        if(BattleManager.instance.SelectCard(handId))
        {
            JankenController.instance.ImageClick();
        }
    }
}
