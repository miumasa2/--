using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HP : MonoBehaviour
{
    public Transform hpBar;
    private int maxHp;  // �ő�HP
    private int hp;     // ����HP
    
    // HP��ݒ肷��
    public void SetHP(int h)
    {
        maxHp = h;
        hp = h;
        ShowHP();
    }
    
    // �_���[�W����
    public void Damage(int d)
    {
        hp -= d;
        if(hp < 0)
        {
            hp = 0;
        }
        ShowHP();
    }
    
    // HP��\������
    public void ShowHP()
    {
        Vector3 scale = hpBar.localScale;
        scale.x = (float) hp / maxHp;
        hpBar.localScale = scale;
    }
    
    // �ő�HP�ƌ���HP���w�肵�ĕ\������
    public void ShowHP(int mH, int h)
    {
        Vector3 scale = hpBar.localScale;
        scale.x = (float) h / mH;
        hpBar.localScale = scale;
    }
    
    // ����HP���擾
    public int GetHP()
    {
        return hp;
    }
    
    // ����HP�𑝂₷�iHP�񕜂̍ۂɎg�p�j
    public void PlusHP(int h)
    {
        hp += h;
        if(hp > maxHp)
        {
            hp = maxHp;
        }
        ShowHP();
    }
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
