using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

// バトル
public class JankenController : MonoBehaviour
{
    [SerializeField] private BattleManager battleManager;
    [SerializeField] private JankenDirector jankenDirector;
    
    [SerializeField] private Enemy enemy;
    
    public static JankenController instance;
    void Awake()
    {
        instance = this;
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // 共通の処理
    public void ImageClick()
    {
        if(battleManager.IsAllOK())
        {
            // 動作可能ならじゃんけんを行う
            int playerScore = battleManager.GetPlayerJanken();
            int enemyScore = enemy.GetJanken();

            jankenDirector.ShowResult(playerScore, enemyScore);
        }
    }
}
